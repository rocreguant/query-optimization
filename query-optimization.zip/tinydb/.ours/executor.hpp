#ifndef EXECUTOR_HPP
#define EXECUTOR_HPP

#include "query-struct.h"


class Executor  {

		public: 
		Executor(); 
		~Executor(); 
		void execute(query q); 
		
		
		private: 


}


#endif

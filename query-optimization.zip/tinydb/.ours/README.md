query-optimization
==================
Authors:
 - Alexandra Nordin
 - Roc Reguant
 
Current version:
	Exercise 1
	
Test cases:
	in.txt
	
Usage:
	Find the directory with the console. 
	Execute the command make.
	Create a file with the query (each argument one line, like the test case).
	Execute the program withe the command "a.out < test.txt "

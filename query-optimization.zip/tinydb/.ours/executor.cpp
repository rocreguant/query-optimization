#include "executor.hpp"

#include "Database.hpp"
#include "operator/Tablescan.hpp"
#include "operator/CrossProduct.hpp"
#include "operator/Selection.hpp"
#include "operator/Projection.hpp"
#include "operator/Printer.hpp"
#include "operator/Chi.hpp"
#include <iostream>
using namespace std;



void Executor:execute(query q){
	
	
}


//Constructor
Executor::Executor(){
}


//Desctructor
Executor::~Executor(){

}
